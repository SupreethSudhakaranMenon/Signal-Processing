[h,t] = impz([1 -5 6],[1 -2.5 1]); 
stem(t,h); 
title("Plot impulse response of filter"); 
xlabel("time(t)"); 
ylabel("Magnitude(h(n))"); 

