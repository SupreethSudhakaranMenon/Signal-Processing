N = 1; 
D = [1 -0.9]; 
zplane(N,D);
title("Z-domain plot"); 
xlabel("Real(z)");
ylabel("Imaginary(z)"); 

