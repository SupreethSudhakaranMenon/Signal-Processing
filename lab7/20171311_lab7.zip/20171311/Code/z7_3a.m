zplane([1 -5 6],[1 -2.5 1]); 
title("Z-domain plot"); 
xlabel("Real part(z)"); 
ylabel("Imaginary part(z)"); 
